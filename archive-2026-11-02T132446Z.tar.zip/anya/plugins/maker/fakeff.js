module.exports = {
  name: 'fakeff2',
  command: ['fakeff2', 'ff2'],
  category: 'canvas',
  desc: 'Bikin gambar Fake FF Single (Xrina API)',
  usage: '<username>',
  cooldown: 5,

  run: async ({ sock, msg, from, sender, args, text, prefix, reply }) => {
    // Validasi input username
    if (!text || !text.trim()) {
      return reply(`⚠️ Masukkan username!\n\nContoh:\n\`${prefix}fakeff2 Xell\``);
    }

    const usn = text.trim();

    await sock.sendMessage(from, { react: { text: '🕕', key: msg.key } });

    try {
      // Encode username untuk URL
      const encodedUsn = encodeURIComponent(usn);
      const imageUrl = `https://apiii-xrina.my.id/canvas/fakeff2?usn=${encodedUsn}`;

      // Kirim langsung menggunakan URL image
      await sock.sendMessage(
        from,
        {
          image: { url: imageUrl },
          caption: `🎮 *FAKE FF (SINGLE)*\n\n👤 *Username:* ${usn}`
        },
        { quoted: msg }
      );

      await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });

    } catch (err) {
      console.error('[FakeFF2 Error]', err);
      await sock.sendMessage(from, { react: { text: '❌', key: msg.key } });
      return reply(`❌ Gagal membuat gambar Fake FF. Server API mungkin sedang down.`);
    }
  }
};