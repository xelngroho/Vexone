const axios = require('axios');
const FormData = require('form-data');
const { downloadMediaMessage } = require('@whiskeysockets/baileys');

module.exports = {
  name: 'smeme',
  command: ['smeme', 'memesi'],
  category: 'maker',
  desc: 'Bikin gambar meme dari gambar yang di-reply',
  usage: '<teks_atas> | <teks_bawah>',
  cooldown: 5,

  run: async ({ sock, msg, from, sender, args, text, prefix, reply }) => {
    // 1. Validasi teks
    if (!text || !text.includes('|')) {
      return reply(`⚠️ Format salah!\n\nGunakan (sambil reply/kirim gambar):\n\`${prefix}smeme teks_atas | teks_bawah\`\n\nContoh:\n\`${prefix}smeme Ketika | Bot Error\``);
    }

    // 2. Cek apakah ada gambar di pesan atau pesan yang di-reply
    let isImage = false;
    let mediaMsg = msg;

    if (msg.message?.imageMessage) {
        isImage = true;
    } else if (msg.message?.extendedTextMessage?.contextInfo?.quotedMessage?.imageMessage) {
        isImage = true;
        // Bikin struktur pesan buat ngedownload gambar yang di-reply
        mediaMsg = {
            key: {
                remoteJid: from,
                id: msg.message.extendedTextMessage.contextInfo.stanzaId,
                participant: msg.message.extendedTextMessage.contextInfo.participant
            },
            message: msg.message.extendedTextMessage.contextInfo.quotedMessage
        };
    }

    if (!isImage) {
        return reply('❌ Harap kirim gambar atau reply gambar yang mau dijadikan meme.');
    }

    const parts = text.split('|').map(s => s.trim());
    const topText = encodeURIComponent(parts[0] || '');
    const bottomText = encodeURIComponent(parts[1] || '');

    await sock.sendMessage(from, { react: { text: '🕕', key: msg.key } });

    try {
        // 3. Download gambar dari WhatsApp
        const imageBuffer = await downloadMediaMessage(mediaMsg, 'buffer', {}, { logger: console });
        if (!imageBuffer) throw new Error('Gagal mendownload gambar dari WhatsApp.');

        // 4. Upload ke Catbox (karena API Xrina butuh URL publik)
        const form = new FormData();
        form.append('reqtype', 'fileupload');
        form.append('fileToUpload', imageBuffer, { filename: 'smeme.jpg' });
        
        const { data: imageUrl } = await axios.post('https://catbox.moe/user/api.php', form, {
            headers: form.getHeaders(),
            timeout: 30000
        });

        if (!imageUrl || !imageUrl.startsWith('http')) {
            throw new Error('Gagal upload gambar ke server temporary.');
        }

        // 5. Tembak API Xrina
        const apiUrl = `https://apiii-xrina.my.id/maker/smeme?url=${encodeURIComponent(imageUrl)}&top=${topText}&bottom=${bottomText}`;

        await sock.sendMessage(from, {
            image: { url: apiUrl },
            caption: `😂 *KaWRoU MD - SMEME*\n\n*Powered by KawRou*`
        }, { quoted: msg });

        await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });

    } catch (error) {
        console.error('[SMEME Error]', error.message);
        await sock.sendMessage(from, { react: { text: '❌', key: msg.key } });
        return reply(`❌ *GAGAL MEMBUAT MEME*\n\n> ${error.message}`);
    }
  }
};
