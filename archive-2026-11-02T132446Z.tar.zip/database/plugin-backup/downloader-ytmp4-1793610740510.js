// Port dari 'plugin baru' (ytmp4.js) — logika & teks output sama dengan plugin asal; dijalankan lewat lib/sahril.js.
const S = require('../../lib/sahril')
const {download, searchYouTube} = require('../../lib/sahril/yt')

const handler = async (m, { sock, text, reply, usedPrefix, command }) => {
	const botName = global.namaBot;
	const input = (text || (m.quoted ? (m.quoted.text || m.quoted.caption) : ''))?.trim();

	if (!input) {
		return reply(
			'*YOUTUBE VIDEO DOWNLOADER (YTMP4)*\n\n' +
			'Format:\n' +
			'- `' + usedPrefix + command + ' <link youtube / kata kunci>`\n' +
			'- Atau balas pesan yang berisi link YouTube\n\n' +
			'*Contoh:*\n' +
			'- `' + usedPrefix + command + ' https://youtu.be/xxxx`\n' +
			'- `' + usedPrefix + command + ' honeystars`'
		);
	}

	await sock.sendMessage(m.chat, { react: { text: '\u23F3', key: m.key } }).catch(() => null);

	try {
		let videoUrl = input;
		const isYoutubeUrl = /youtu\.?be/i.test(videoUrl);

		if (!isYoutubeUrl) {
			const searchRes = await searchYouTube(videoUrl);
			if (!searchRes || !searchRes.url) {
				await sock.sendMessage(m.chat, { react: { text: '\u274C', key: m.key } }).catch(() => null);
				return reply('Video tidak ditemukan untuk kata kunci: "' + input + '"');
			}
			videoUrl = searchRes.url;
		}

		const res = await download(videoUrl, '720');

		if (!res || !res.downloadUrl) {
			await sock.sendMessage(m.chat, { react: { text: '\u274C', key: m.key } }).catch(() => null);
			throw new Error('Gagal mengambil URL unduhan video dari server.');
		}

		const sizeMB = res.file?.contentLength
			? (res.file.contentLength / (1024 * 1024)).toFixed(2) + ' MB'
			: 'Unknown';

		const caption = [
			'*YOUTUBE VIDEO DOWNLOADER*',
			'----------------------------------------',
			'*Judul:* ' + (res.title || 'YouTube Video'),
			'*Ukuran:* ' + sizeMB,
			'*Kualitas:* 720p',
			'*Sumber:* ' + videoUrl,
			'',
			`© ${botName}`
		].join('\n');

		await sock.sendMessage(
			m.chat,
			{
				video: { url: res.downloadUrl },
				mimetype: 'video/mp4',
				caption: caption
			},
			{ quoted: m }
		);

		await sock.sendMessage(m.chat, { react: { text: '\u2728', key: m.key } }).catch(() => null);

	} catch (err) {
		console.error('[YTMP4 ERROR]:', err);
		await sock.sendMessage(m.chat, { react: { text: '\u274C', key: m.key } }).catch(() => null);
		return reply('Gagal memproses video YouTube: ' + (err.message || err));
	}
};

handler.help = ['ytmp4 <url/query>', 'ytv <url/query>'];
handler.tags = ['downloader'];
handler.command = ['ytmp4', 'ytv'];
handler.limit = true;

module.exports = S.wrap(handler, {"category": "downloader", "extra": ["ytvideo"]})
