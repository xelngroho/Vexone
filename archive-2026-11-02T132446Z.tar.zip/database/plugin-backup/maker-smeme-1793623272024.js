const axios = require('axios');
const FormData = require('form-data');
const { downloadMediaMessage } = require('@whiskeysockets/baileys');

// Fungsi bantuan buat upload gambar ke server publik
async function uploadImage(buffer) {
    // --- METODE 1: TELEGRAPH (Paling stabil buat bot) ---
    try {
        const form = new FormData();
        form.append('file', buffer, { filename: 'image.jpg' });
        
        const res = await axios.post('https://telegra.ph/upload', form, {
            headers: form.getHeaders(),
            timeout: 15000
        });
        
        if (res.data && res.data[0] && res.data[0].src) {
            return 'https://telegra.ph' + res.data[0].src;
        }
    } catch (e) {
        console.log('[SMEME] Telegra.ph gagal, mencoba Catbox...');
    }

    // --- METODE 2: CATBOX (Fallback) ---
    try {
        const form = new FormData();
        form.append('reqtype', 'fileupload');
        form.append('fileToUpload', buffer, { filename: 'smeme.jpg' });
        
        const { data: imageUrl } = await axios.post('https://catbox.moe/user/api.php', form, {
            headers: {
                ...form.getHeaders(),
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
            },
            timeout: 30000
        });

        if (imageUrl && imageUrl.startsWith('http')) return imageUrl;
    } catch (e) {
        console.log('[SMEME] Catbox gagal.');
    }

    throw new Error('Semua server upload gambar sedang down.');
}

module.exports = {
  name: 'smeme',
  command: ['smeme', 'memesi'],
  category: 'maker',
  desc: 'Bikin gambar meme dari gambar yang di-reply',
  usage: '<teks_atas> | <teks_bawah>',
  cooldown: 5,

  run: async ({ sock, msg, from, sender, args, text, prefix, reply }) => {
    if (!text || !text.includes('|')) {
      return reply(`⚠️ Format salah!\n\nGunakan (sambil reply/kirim gambar):\n\`${prefix}smeme teks_atas | teks_bawah\`\n\nContoh:\n\`${prefix}smeme Ketika | Bot Error\``);
    }

    let isImage = false;
    let mediaMsg = msg;

    if (msg.message?.imageMessage) {
        isImage = true;
    } else if (msg.message?.extendedTextMessage?.contextInfo?.quotedMessage?.imageMessage) {
        isImage = true;
        mediaMsg = {
            key: {
                remoteJid: from,
                id: msg.message.extendedTextMessage.contextInfo.stanzaId,
                participant: msg.message.extendedTextMessage.contextInfo.participant
            },
            message: msg.message.extendedTextMessage.contextInfo.quotedMessage
        };
    }

    if (!isImage) {
        return reply('❌ Harap kirim gambar atau reply gambar yang mau dijadikan meme.');
    }

    const parts = text.split('|').map(s => s.trim());
    const topText = encodeURIComponent(parts[0] || '');
    const bottomText = encodeURIComponent(parts[1] || '');

    await sock.sendMessage(from, { react: { text: '🕕', key: msg.key } });

    try {
        const imageBuffer = await downloadMediaMessage(mediaMsg, 'buffer', {}, { logger: console });
        if (!imageBuffer) throw new Error('Gagal mendownload gambar dari WhatsApp.');

        // Upload gambar
        const imageUrl = await uploadImage(imageBuffer);

        // Tembak API Xrina pake User-Agent browser
        const apiUrl = `https://apiii-xrina.my.id/maker/smeme?url=${encodeURIComponent(imageUrl)}&top=${topText}&bottom=${bottomText}`;
        
        await sock.sendMessage(from, {
            image: { url: apiUrl },
            caption: `😂 *KaWRoU MD - SMEME*\n\n*Powered by KawRou*`
        }, { quoted: msg });

        await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });

    } catch (error) {
        console.error('[SMEME Error]', error.message);
        await sock.sendMessage(from, { react: { text: '❌', key: msg.key } });
        return reply(`❌ *GAGAL MEMBUAT MEME*\n\n> ${error.message}`);
    }
  }
};
