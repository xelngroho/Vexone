const axios = require('axios');

module.exports = {
  name: 'autodownload',
  command: [], // Sengaja dikosongkan biar ga kepanggil pake prefix
  category: 'download',
  desc: 'Auto-detect link TikTok/YouTube/IG dll. tanpa prefix',
  usage: 'Kirim link aja langsung',
  cooldown: 10,

  run: async ({ sock, msg, from, sender, args, text, prefix, reply }) => {
    // 1. Ambil teks pesan (kalau ada)
    const rawText = text || (args ? args.join(' ') : '') || '';
    
    // 2. Regex deteksi URL (http/https)
    const urlRegex = /(https?:\/\/[^\s]+)/g;
    const matches = rawText.match(urlRegex);

    // Kalau ga ada link, abaikan (return false biar bot lanjut ke handler lain)
    if (!matches || matches.length === 0) return;

    const url = matches[0];

    // 3. Daftar domain yang didukung sama API AIO
    const supportedDomains = [
      'tiktok.com', 'youtube.com', 'youtu.be', 'instagram.com', 
      'facebook.com', 'fb.watch', 'twitter.com', 'x.com', 
      'capcut.com', 'bilibili.com', 'pinterest.com'
    ];

    // Cek apakah domainnya didukung
    const isSupported = supportedDomains.some(domain => url.includes(domain));
    if (!isSupported) return; // Kalau ga didukung, skip

    // 4. Jangan proses kalau pesan diawali prefix command (misal .ytmp4 <url>)
    if (rawText.startsWith(prefix)) return;

    // Kasih reaksi loading
    await sock.sendMessage(from, { react: { text: '🕕', key: msg.key } });

    try {
      // 5. Tembak API Nexray AIO
      const apiUrl = `https://api.nexray.eu.cc/downloader/aio?url=${encodeURIComponent(url)}`;
      const { data: res } = await axios.get(apiUrl, { timeout: 60000 });

      // Validasi response
      if (!res || !res.status || !res.result) {
        throw new Error('Gagal mengambil data dari API.');
      }

      const result = res.result;
      const medias = result.medias || [];

      if (medias.length === 0) {
        throw new Error('Tidak ada media yang ditemukan di link tersebut.');
      }

      // 6. Ambil media pertama (biasanya kualitas HD)
      const media = medias[0];
      
      // Susun caption
      let caption = 
        `📥 *KaWRoU MD - AUTO DOWNLOADER*\n\n` +
        `🌐 *Platform:* ${result.source?.toUpperCase() || 'Unknown'}\n` +
        `👤 *Author:* ${result.author || '-'}\n` +
        `📝 *Judul:* ${result.title || '-'}\n`;

      // Tambahin info durasi kalau ada (dalam milidetik)
      if (result.duration) {
        const sec = Math.floor(result.duration / 1000);
        caption += `⏱️ *Durasi:* ${Math.floor(sec / 60)}m ${sec % 60}s\n`;
      }

      // Tambahin info statistik kalau ada
      if (result.statistics) {
        const stats = result.statistics;
        caption += `\n📊 *Statistik:*\n`;
        if (stats.play_count) caption += `> 👀 Views: ${stats.play_count.toLocaleString()}\n`;
        if (stats.digg_count) caption += `> ❤️ Likes: ${stats.digg_count.toLocaleString()}\n`;
        if (stats.comment_count) caption += `> 💬 Comments: ${stats.comment_count.toLocaleString()}\n`;
      }

      caption += `\n*Powered by KawRou*`;

      // 7. Kirim media sesuai tipenya
      if (media.type === 'video') {
        await sock.sendMessage(from, {
          video: { url: media.url },
          caption: caption,
          mimetype: 'video/mp4'
        }, { quoted: msg });
      } else if (media.type === 'image') {
        await sock.sendMessage(from, {
          image: { url: media.url },
          caption: caption
        }, { quoted: msg });
      } else {
        // Fallback kalau tipenya ga jelas, kirim sebagai dokumen
        await sock.sendMessage(from, {
          document: { url: media.url },
          fileName: `media.${media.extension || 'mp4'}`,
          mimetype: 'application/octet-stream',
          caption: caption
        }, { quoted: msg });
      }

      await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });

    } catch (error) {
      console.error('[AutoDownload Error]', error.message);
      await sock.sendMessage(from, { react: { text: '❌', key: msg.key } });
      // Opsional: kasih tau error ke user, atau diem aja biar ga spam
      // reply(`❌ Gagal mendownload: ${error.message}`);
    }
  }
};
