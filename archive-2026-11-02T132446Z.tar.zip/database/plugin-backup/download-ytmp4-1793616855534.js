// Port dari Ourin (download/ytmp4.js). Kode asli utuh di ourin/plugins/download/ytmp4.js; dijalankan lewat lib/ourin.js.
module.exports = require('../../../lib/ourin').plugin("download/ytmp4", {
  "name": "ytmp4",
  "command": [
    "ytmp4",
    "youtubemp4",
    "ytvideo"
  ],
  "category": "download",
  "desc": "Download video YouTube",
  "usage": ".ytmp4 <url>",
  "owner": false,
  "group": false,
  "private": false,
  "premium": false,
  "admin": false,
  "botAdmin": false,
  "cooldown": 20,
  "energi": 2,
  "needs": {
    "apikeys": [],
    "scrapers": [],
    "assets": []
  }
})
