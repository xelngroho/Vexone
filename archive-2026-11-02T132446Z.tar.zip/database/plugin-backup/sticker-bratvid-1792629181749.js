// Port dari Ourin (sticker/bratvid.js). Kode asli utuh di ourin/plugins/sticker/bratvid.js; dijalankan lewat lib/ourin.js.
module.exports = require('../../../lib/ourin').plugin("sticker/bratvid", {
  "name": "bratvid",
  "command": [
    "bratvid",
    "bratvideo"
  ],
  "category": "sticker",
  "desc": "Membuat sticker brat animated",
  "usage": ".bratvid <text>",
  "owner": false,
  "group": false,
  "private": false,
  "premium": false,
  "admin": false,
  "botAdmin": false,
  "cooldown": 15,
  "energi": 1,
  "needs": {
    "apikeys": [],
    "scrapers": [],
    "assets": []
  }
})
