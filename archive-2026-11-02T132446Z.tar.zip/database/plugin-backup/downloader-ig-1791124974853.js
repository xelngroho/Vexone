'use strict';
const axios = require('axios');

let sessionCache = null;

async function getInstagramSession() {
  const now = Date.now();
  if (sessionCache && sessionCache.expiresAt > now && sessionCache.csrf) {
    return { csrf: sessionCache.csrf, cookies: sessionCache.cookies };
  }
  const userAgent = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36";
  const homeRes = await axios.get("https://www.instagram.com/", {
    headers: {
      "User-Agent": userAgent,
      "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
      "Accept-Language": "en-US,en;q=0.8",
    },
    timeout: 10000,
    validateStatus: () => true,
    maxRedirects: 0,
  });
  const rawCookies = homeRes.headers["set-cookie"] || [];
  const cookieStr = rawCookies.map((c) => c.split(";")[0]).join("; ");
  const csrfMatch = cookieStr.match(/csrftoken=([^;]+)/);
  const csrf = csrfMatch? csrfMatch[1] : "";
  sessionCache = { csrf, cookies: cookieStr, expiresAt: now + 20 * 60 * 1000 };
  return { csrf, cookies: cookieStr };
}

function extractShortcode(url) {
  const match = url.match(/(?:p|reel|reels)\/([A-Za-z0-9_-]+)/);
  if (match) return match[1];
  const parts = url.split("?")[0].replace(/\/+$/, "").split("/");
  return parts[parts.length - 1] || null;
}

async function extractInstagramMedia(url) {
  const shortcode = extractShortcode(url);
  if (!shortcode) return { status: false, message: "Shortcode IG tidak valid" };
  let { csrf, cookies } = await getInstagramSession();
  const userAgent = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36";

  const fetchItem = async (currentCsrf, currentCookies) => {
    const payload = new URLSearchParams({
      variables: JSON.stringify({ shortcode, __relay_internal__pv__PolarisAIGMMediaWebLabelEnabledrelayprovider: false }),
      doc_id: "27128499623469141",
      server_timestamps: "true",
    });
    return axios.post("https://www.instagram.com/graphql/query", payload.toString(), {
      headers: {
        "User-Agent": userAgent,
        "Accept": "*/*",
        "Accept-Language": "en-US,en;q=0.8",
        "Content-Type": "application/x-www-form-urlencoded",
        "X-CSRFToken": currentCsrf,
        "X-IG-App-ID": "936619743392459",
        "Cookie": currentCookies,
        "Referer": `https://www.instagram.com/p/${shortcode}/`,
      },
      timeout: 15000,
      validateStatus: () => true,
    });
  };

  let res = await fetchItem(csrf, cookies);
  if (res.status!== 200 ||!res.data?.data) {
    sessionCache = null;
    const refreshed = await getInstagramSession();
    csrf = refreshed.csrf; cookies = refreshed.cookies;
    res = await fetchItem(csrf, cookies);
  }

  const items = res.data?.data?.xdt_api__v1__media__shortcode__web_info?.items;
  if (!items ||!items.length) return { status: false, message: "Media tidak ditemukan / akun privat." };
  const item = items[0];
  const downloadUrls = [];
  if (Array.isArray(item.carousel_media) && item.carousel_media.length > 0) {
    for (const sub of item.carousel_media) {
      if (sub.video_versions?.length) downloadUrls.push(sub.video_versions[0].url);
      else if (sub.image_versions2?.candidates?.[0]?.url) downloadUrls.push(sub.image_versions2.candidates[0].url);
    }
  } else {
    if (item.video_versions?.length) downloadUrls.push(item.video_versions[0].url);
    else if (item.image_versions2?.candidates?.[0]?.url) downloadUrls.push(item.image_versions2.candidates[0].url);
  }
  const uniqueUrls = [...new Set(downloadUrls)];
  if (!uniqueUrls.length) return { status: false, message: "Link download tidak ditemukan." };

  return {
    status: true,
    downloadUrl: uniqueUrls,
    metadata: {
      username: item.user?.username || "-",
      full_name: item.user?.full_name || "",
      caption: item.caption?.text || "",
      likes: item.like_count?? 0,
      comments: item.comment_count?? 0,
      is_video:!!item.video_versions,
    }
  };
}

module.exports = {
    name: 'ig-vamx',
    command: ['ig', 'igdl', 'instagram', 'reels', 'igvamx'],
    category: 'downloader',
    desc: 'Download IG Reels/Video/Foto via Vamx Native API',
    run: async ({ sock, msg, from, args, reply }) => {
        if (!args[0]) return reply(`❌ Mana link IG nya wok?\n\nContoh:\n.ig https://www.instagram.com/reel/DdL4EZcu7Aw/`);
        const url = args[0];
        if (!url.includes('instagram.com')) return reply('❌ Link harus dari instagram.com');

        await reply('⏳ *Memproses link IG...*');
        try {
            const data = await extractInstagramMedia(url);
            if (!data.status) return reply(`❌ Gagal: ${data.message}`);

            const meta = data.metadata;
            let caption = `✅ *IG DOWNLOADER - VamxAPI*\n\n`;
            caption += `👤 @${meta.username} (${meta.full_name})\n`;
            caption += `❤️ ${meta.likes} | 💬 ${meta.comments}\n`;
            caption += `📝 ${meta.caption.slice(0, 300)}\n\n`;
            caption += `🔗 ${url}`;

            for (let i = 0; i < data.downloadUrl.length; i++) {
                const mediaUrl = data.downloadUrl[i];
                const isVideo = mediaUrl.includes('.mp4') || meta.is_video;
                if (isVideo) {
                    await sock.sendMessage(from, { video: { url: mediaUrl }, caption: i === 0? caption : '', mimetype: 'video/mp4' }, { quoted: msg });
                } else {
                    await sock.sendMessage(from, { image: { url: mediaUrl }, caption: i === 0? caption : '' }, { quoted: msg });
                }
            }
        } catch (e) {
            console.log(e);
            reply(`❌ Error: ${e.message}`);
        }
    }
};
