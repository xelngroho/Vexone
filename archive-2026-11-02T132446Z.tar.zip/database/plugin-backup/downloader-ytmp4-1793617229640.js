const axios = require('axios');

module.exports = {
  name: 'ytmp4',
  command: ['ytmp4', 'ytv', 'ytvideo'],
  category: 'download',
  desc: 'Download video dari YouTube (MP4)',
  usage: '<url_youtube> [kualitas]',
  cooldown: 15,

  run: async ({ sock, msg, from, sender, args, text, prefix, reply }) => {
    if (!text || !text.trim()) {
      return reply(`⚠️ Masukkan link YouTube!\n\nContoh:\n\`${prefix}ytmp4 https://youtu.be/xxxx 360p\``);
    }

    const argsParts = text.trim().split(/\s+/);
    const url = argsParts[0];
    const qualityReq = argsParts[1] ? argsParts[1].toLowerCase() : '360p';

    if (!url.includes('youtube.com') && !url.includes('youtu.be')) {
      return reply('❌ Link tidak valid. Pastikan link berasal dari YouTube.');
    }

    await sock.sendMessage(from, { react: { text: '🕕', key: msg.key } });
    await reply('⏳ *Sedang memproses video YouTube...*');

    try {
      const apiUrl = `https://apiii-xrina.my.id/download/ytmp4?url=${encodeURIComponent(url)}`;
      const { data: res } = await axios.get(apiUrl, { timeout: 30000 });

      if (!res || !res.status || !res.data || !res.data.media) {
        throw new Error('Gagal mengambil data dari API. Pastikan link valid.');
      }

      const info = res.data;
      const mediaList = info.media;

      let selectedMedia = mediaList.find(m => m.quality === qualityReq);
      if (!selectedMedia) {
        selectedMedia = mediaList.find(m => m.quality === '360p') || mediaList[0];
      }

      if (!selectedMedia || !selectedMedia.url) {
        throw new Error('Link download video tidak ditemukan.');
      }

      const caption = 
        `🎬 *KaWRoU MD - YOUTUBE DL*\n\n` +
        `📌 *Judul:* ${info.title || 'Tanpa Judul'}\n` +
        `⏱️ *Durasi:* ${info.duration_label || '-'}\n` +
        `📺 *Kualitas:* ${selectedMedia.quality}\n` +
        `📦 *Ukuran:* ${selectedMedia.size}\n\n` +
        `*Powered by KawRou*`;

      await sock.sendMessage(
        from,
        {
          video: { url: selectedMedia.url },
          caption: caption,
          mimetype: 'video/mp4'
        },
        { quoted: msg }
      );

      await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });

    } catch (error) {
      console.error('[YTMP4 Error]', error.message);
      await sock.sendMessage(from, { react: { text: '❌', key: msg.key } });
      return reply(`❌ *GAGAL DOWNLOAD*\n\n> ${error.message}`);
    }
  },
};
