// Port dari Ourin (owner/checkban.js). Kode asli utuh di ourin/plugins/owner/checkban.js; dijalankan lewat lib/ourin.js.
module.exports = require('../../../lib/ourin').plugin("owner/checkban", {
  "name": "checkban",
  "command": [
    "checkban"
  ],
  "category": "owner",
  "desc": "Check actual ban state",
  "usage": ".checkban",
  "owner": true,
  "group": false,
  "private": false,
  "premium": false,
  "admin": false,
  "botAdmin": false,
  "cooldown": 0,
  "energi": 0,
  "needs": {
    "apikeys": [],
    "scrapers": [],
    "assets": []
  }
})
