const { Sticker, StickerTypes } = require('wa-sticker-formatter')
const { getMedia } = require('../../lib/utils')

module.exports = {
  name: 'sticker',
  command: ['s', 'sticker', 'stiker'],
  category: 'sticker',
  desc: 'Gambar/video jadi stiker (kirim atau reply media)',
  run: async ({ sock, msg, from, config, prefix, reply }) => {
    const media = await getMedia(sock, msg, ['imageMessage', 'videoMessage'])
    if (!media) return reply(`Kirim atau reply gambar/video dengan caption ${prefix}s`)

    if (media.type === 'videoMessage' && (media.info.seconds || 0) > 10) {
      return reply('Durasi video maksimal 10 detik.')
    }

    const sticker = new Sticker(media.buffer, {
      pack: config.stickerPack,
      author: config.stickerAuthor,
      type: StickerTypes.FULL,
      quality: 60
    })
    await sock.sendMessage(from, { sticker: await sticker.toBuffer() }, { quoted: msg })
  }
}
