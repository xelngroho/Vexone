const axios = require('axios')
const { getUrl, hostIs, fetchBuffer } = require('../../lib/downloader')

const UA = 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36'
const fmt = (n) => (Number.isFinite(Number(n)) ? Number(n) : 0).toLocaleString('id-ID')

// Susun teks hasil seperti tampilan "ALIGHT MOTION PRESET"
function render(result) {
  const video = result.video || {}
  const user = result.user || {}
  const preset = result.preset || {}
  // Nama field statistik bisa berbeda antar respons; coba beberapa kemungkinan
  const views = video.views ?? video.play_count ?? video.playCount ?? result.views ?? result.play_count ?? 0
  const likes = video.likes ?? video.digg_count ?? video.diggCount ?? result.likes ?? result.digg_count ?? 0
  const comments = video.comments ?? video.comment_count ?? video.commentCount ?? result.comments ?? result.comment_count ?? 0
  const items = Array.isArray(preset.items) ? preset.items.filter((i) => i && i.url) : []

  let t =
`╭─「 *ALIGHT MOTION PRESET* 」
│
│ 👤 *Creator:* ${user.display_name || '-'}
│ 🔗 *Username:* @${user.username || '-'}
│
│ 🎬 *Caption:*
│ ${String(video.caption ?? '-').replace(/\n/g, '\n│ ')}
│
│ 👁️ *Views:* ${fmt(views)}
│ ❤️ *Likes:* ${fmt(likes)}
│ 💬 *Comments:* ${fmt(comments)}
│ ⏱️ *Duration:* ${video.duration ?? 0}s
│
│ 📦 *Preset:*
│ ${preset.is_reply ? 'Reply Comment' : 'Comment'}
│ ${preset.is_author ? 'Author' : 'User'}
╰─────────────────`

  if (items.length) {
    t += '\n\n╭─「 *DOWNLOAD PRESET* 」'
    for (const it of items) t += `\n│ 📁 *${it.label || 'Preset'}*\n│ 🔗 ${it.url}\n`
    t += '╰─────────────────'
  }
  if (video.url) t += `\n\n🎥 *TikTok:*\n${video.url}`
  return t
}

module.exports = {
  render,
  name: 'amfind',
  command: ['amfind', 'amfinder', 'presetam', 'amtiktok'],
  category: 'tools',
  desc: 'Cari preset Alight Motion dari video TikTok',
  usage: '<link tiktok>',
  run: async ({ sock, msg, from, args, prefix, react, reply }) => {
    const url = getUrl(args)
    if (!url) return reply(`❌ Masukkan link TikTok.\n\nContoh:\n${prefix}amfind https://vt.tiktok.com/ZSb5ce1L7/`)
    if (!hostIs(url, ['tiktok.com'])) return reply('❌ URL harus berupa link TikTok yang valid.')

    react('⏳')
    let data
    try {
      const res = await axios.get('https://bintangapi.my.id/api/amfind/', {
        params: { url },
        headers: {
          Accept: '*/*',
          'Accept-Language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7',
          Connection: 'keep-alive',
          Origin: 'https://starlabs.biz.id',
          Referer: 'https://starlabs.biz.id/',
          'Sec-Fetch-Dest': 'empty',
          'Sec-Fetch-Mode': 'cors',
          'Sec-Fetch-Site': 'cross-site',
          'User-Agent': UA
        },
        timeout: 30000,
        validateStatus: () => true
      })
      if (res.status >= 400) throw new Error(`HTTP ${res.status}`)
      data = typeof res.data === 'string' ? (() => { try { return JSON.parse(res.data) } catch { return null } })() : res.data
    } catch (err) {
      console.log('[AMFIND]', err.message)
      return reply(`❌ Terjadi kesalahan: ${String(err.message).slice(0, 100)}. Coba lagi nanti.`)
    }

    if (!data?.success || !data?.data) {
      console.log('[AMFIND] respons tanpa data:', JSON.stringify(data)?.slice(0, 300))
      return reply('❌ Preset tidak ditemukan.')
    }

    const text = render(data.data)
    const thumb = data.data.thumbnail
    if (thumb) {
      try {
        const { buffer } = await fetchBuffer(thumb)
        return await sock.sendMessage(from, { image: buffer, caption: text }, { quoted: msg })
      } catch (err) {
        console.log('[AMFIND] thumbnail gagal, kirim teks:', err.message)
      }
    }
    await sock.sendMessage(from, { text }, { quoted: msg })
  }
}
