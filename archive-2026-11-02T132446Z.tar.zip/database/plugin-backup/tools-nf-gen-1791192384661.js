const ENDPOINT = "https://token-netflix.vercel.app/api/generate";
const CREATOR = "vanXone";

const HEADERS = {
  "Content-Type": "application/json",
};

function buildLinks(token) {
  return {
    pc: `https://www.netflix.com/browse?nftoken=${token}`,
    android: `nflx://www.netflix.com/browse?nftoken=${token}`,
    tv: `https://www.netflix.com/tv?nftoken=${token}`,
  };
}

function cleanToken(item) {
  return {
    id: item.id,
    index: item.index,
    success: item.success,
    token: item.token,
    expiry: item.expiry || null,
    type: item.type || "cookie",
    profile: item.profile || null,
    links: item.token ? buildLinks(item.token) : item.links || null,
    generatedAt: item.generatedAt || null,
  };
}

async function generateNetflix(count = 1, stream = false) {
  const started = Date.now();
  try {
    const res = await fetch(ENDPOINT, {
      method: "POST",
      headers: HEADERS,
      body: JSON.stringify({ count, stream }),
    });
    const text = await res.text();
    let data;
    try { data = JSON.parse(text); } catch { data = { raw: text }; }

    if (!res.ok) {
      return { creator: CREATOR, status: "failed", code: res.status, input: { count, stream }, error: data, time_ms: Date.now() - started };
    }
    const tokens = Array.isArray(data.data) ? data.data.map(cleanToken) : [];
    return {
      creator: CREATOR,
      status: "success",
      code: res.status,
      input: { count, stream },
      totalRequested: data.totalRequested ?? count,
      successCount: data.successCount ?? tokens.filter((t) => t.success).length,
      errorCount: data.errorCount ?? 0,
      total_returned: tokens.length,
      tokens,
      errors: data.errors || [],
      time_ms: Date.now() - started,
    };
  } catch (error) {
    return { creator: CREATOR, status: "failed", input: { count, stream }, error: error.message, time_ms: Date.now() - started };
  }
}

module.exports = {
  name: 'nf-gen',
  command: ['nf-gen', 'netflix', 'nfgen'],
  category: 'premium',
  desc: 'Generate token netflix by vanXone',
  usage: '[jumlah 1-10]',
  run: async ({ sock, msg, from, args, text, prefix, reply }) => {
    const count = parseInt(args[0]) || 1;
    const stream = args.includes('--stream');

    if (count < 1 || count > 10) {
      return reply(`❌ Jumlah harus 1-10\nContoh: ${prefix}nf-gen 3\nCreator: ${CREATOR}`);
    }

    try {
      await reply(`⏳ Generating ${count} token Netflix by ${CREATOR}...`);
      const result = await generateNetflix(count, stream);

      if (result.status === 'failed') {
        return reply(`❌ Gagal generate:\n${JSON.stringify(result.error, null, 2)}`);
      }

      if (!result.tokens || result.tokens.length === 0) {
        return reply(`❌ Tidak ada token yang berhasil di generate`);
      }

      let teks = `✅ *NETFLIX GENERATOR*\n`;
      teks += `👤 Creator: ${CREATOR}\n`;
      teks += `📦 Request: ${result.totalRequested} | Sukses: ${result.successCount}\n`;
      teks += `⏱️ ${result.time_ms}ms\n\n`;

      result.tokens.forEach((t, i) => {
        if (!t.success) return;
        teks += `*TOKEN ${i + 1}*\n`;
        teks += `🔑 Token: \`${t.token.slice(0, 30)}...\`\n`;
        teks += `💻 PC: ${t.links.pc}\n`;
        teks += `📱 TV: ${t.links.tv}\n\n`;
      });

      // Kirim full json juga kalau mau
      teks += `_Full token ada di log console owner_`;

      await reply(teks);

      // Kirim detail lengkap ke chat biar bisa di copy
      for (const t of result.tokens) {
        if (t.success) {
          await sock.sendMessage(from, { text: `TOKEN:\n${t.token}\n\nLINK PC:\n${t.links.pc}` }, { quoted: msg });
        }
      }

    } catch (e) {
      reply(`❌ Error: ${e.message}`);
    }
  }
}
