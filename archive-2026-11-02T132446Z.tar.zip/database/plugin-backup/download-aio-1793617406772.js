// Port dari Ourin (download/aio.js). Kode asli utuh di ourin/plugins/download/aio.js; dijalankan lewat lib/ourin.js.
module.exports = require('../../../lib/ourin').plugin("download/aio", {
  "name": "aio",
  "command": [
    "aio",
    "allinone"
  ],
  "category": "downloader",
  "desc": "All in one downloader (IG, TikTok, FB, Twitter, YouTube, Pinterest, CapCut, dll)",
  "usage": ".aio <url>",
  "owner": false,
  "group": false,
  "private": false,
  "premium": false,
  "admin": false,
  "botAdmin": false,
  "cooldown": 10,
  "energi": 1,
  "needs": {
    "apikeys": [],
    "scrapers": [],
    "assets": []
  }
})
