// Port dari Ourin (canvas/fakeff.js). Kode asli utuh di ourin/plugins/canvas/fakeff.js; dijalankan lewat lib/ourin.js.
module.exports = require('../../../lib/ourin').plugin("canvas/fakeff", {
  "name": "fakeff",
  "command": [
    "fakeff"
  ],
  "category": "canvas",
  "desc": "Bikin gambar banner Fake FF (Solo)",
  "usage": ".fakeff <teks>|[bgNum]",
  "owner": false,
  "group": false,
  "private": false,
  "premium": false,
  "admin": false,
  "botAdmin": false,
  "cooldown": 5,
  "energi": 2,
  "needs": {
    "apikeys": [],
    "scrapers": [],
    "assets": []
  }
})
