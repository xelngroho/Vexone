const fs = require('fs')
const path = require('path')

const dir = path.join(__dirname, '..', '..', 'database')

module.exports = {
  name: 'backup',
  command: ['backup', 'backupdb'],
  category: 'owner',
  desc: 'Kirim file database (JSON) sebagai cadangan',
  owner: true,
  run: async ({ sock, msg, from, reply }) => {
    // simpan dulu data yang masih tertunda di memori
    try {
      require('../../lib/db').save()
      const { flushAll } = require('../../lib/store')
      if (typeof flushAll === 'function') flushAll()
    } catch {}

    if (!fs.existsSync(dir)) return reply('Folder database belum ada.')
    const files = fs.readdirSync(dir).filter((f) => f.endsWith('.json'))
    if (!files.length) return reply('Belum ada data untuk dicadangkan.')

    await reply(`Mengirim ${files.length} file database...`)
    for (const f of files) {
      await sock.sendMessage(
        from,
        { document: fs.readFileSync(path.join(dir, f)), mimetype: 'application/json', fileName: f },
        { quoted: msg }
      )
    }
  }
}
