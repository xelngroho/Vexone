// Port dari 'plugin baru' (ytmp3.js) — logika & teks output sama dengan plugin asal; dijalankan lewat lib/sahril.js.
const S = require('../../lib/sahril')
const {download, searchYouTube} = require('../../lib/sahril/yt')

const handler = async (m, { sock, text, reply, usedPrefix, command }) => {
	const botName = global.namaBot;
	const input = (text || (m.quoted ? (m.quoted.text || m.quoted.caption) : ''))?.trim();

	if (!input) {
		return reply(
			'*YOUTUBE AUDIO DOWNLOADER (YTMP3)*\n\n' +
			'Format:\n' +
			'- `' + usedPrefix + command + ' <link youtube / judul lagu>`\n' +
			'- Atau balas pesan yang berisi link YouTube\n\n' +
			'*Contoh:*\n' +
			'- `' + usedPrefix + command + ' https://youtu.be/xxxx`\n' +
			'- `' + usedPrefix + command + ' honeystars`'
		);
	}

	await sock.sendMessage(m.chat, { react: { text: '\u23F3', key: m.key } }).catch(() => null);

	try {
		let targetUrl = input;
		const isYoutubeUrl = /youtu\.?be/i.test(targetUrl);

		if (!isYoutubeUrl) {
			const searchRes = await searchYouTube(targetUrl);
			if (!searchRes || !searchRes.url) {
				await sock.sendMessage(m.chat, { react: { text: '\u274C', key: m.key } }).catch(() => null);
				return reply('Lagu atau video tidak ditemukan untuk kata kunci: "' + input + '"');
			}
			targetUrl = searchRes.url;
		}

		const res = await download(targetUrl, 'mp3');

		if (!res || !res.downloadUrl) {
			await sock.sendMessage(m.chat, { react: { text: '\u274C', key: m.key } }).catch(() => null);
			throw new Error('Gagal mengambil audio dari server.');
		}

		const cleanTitle = (res.title || 'YouTube Audio').replace(/[\\/:*?"<>|]/g, '');

		await sock.sendMessage(
			m.chat,
			{
				audio: { url: res.downloadUrl },
				mimetype: 'audio/mpeg',
				fileName: `${cleanTitle}.mp3`
			},
			{ quoted: m }
		);

		await sock.sendMessage(m.chat, { react: { text: '\u2728', key: m.key } }).catch(() => null);

	} catch (err) {
		console.error('[YTMP3 ERROR]:', err);
		await sock.sendMessage(m.chat, { react: { text: '\u274C', key: m.key } }).catch(() => null);
		return reply('Gagal memproses audio YouTube: ' + (err.message || err));
	}
};

handler.help = ['ytmp3 <url/query>', 'yta <url/query>'];
handler.tags = ['downloader'];
handler.command = ['ytmp3', 'yta'];
handler.limit = true;

module.exports = S.wrap(handler, {"category": "downloader", "extra": ["ytaudio"]})
