// Port dari plugin_baruuu (canvas/fakeff2.js). Kode asli utuh di ourin/plugins/canvas/fakeff2.js; dijalankan lewat lib/ourin.js.
module.exports = require('../../../lib/ourin').plugin("canvas/fakeff2", {
  "name": "fakeff2",
  "command": [
    "fakeff2"
  ],
  "category": "canvas",
  "desc": "Bikin gambar banner Fake FF (Solo 2)",
  "usage": ".fakeff2 <teks>|[bgNum]",
  "owner": false,
  "group": false,
  "private": false,
  "premium": false,
  "admin": false,
  "botAdmin": false,
  "cooldown": 5,
  "energi": 2,
  "needs": {
    "apikeys": [],
    "scrapers": [],
    "assets": []
  }
})
